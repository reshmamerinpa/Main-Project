﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace orphanage_system.Class
{
    public class Visitors
    {
    }
}