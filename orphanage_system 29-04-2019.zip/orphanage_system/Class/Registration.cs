﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace orphanage_system.Class
{
    public class Registration
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
           
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        //<......User Registration.......>

        private string fname;
        private string lname;
        private string dob;
        private string email_id;
        private string gender;
        private string contact_no;
        private string address;
        private string nationality;
        private string occupation;
        private string password;
        private string job_type;
        private string qualification;
        // private int login_no;



        public string Lname { get => lname; set => lname = value; }
        public string Dob { get => dob; set => dob = value; }
        public string Email_id { get => email_id; set => email_id = value; }
        public string Gender { get => gender; set => gender = value; }
        public string Contact_no { get => contact_no; set => contact_no = value; }
        public string Address { get => address; set => address = value; }
        public string Nationality { get => nationality; set => nationality = value; }
        public string Occupation { get => occupation; set => occupation = value; }
        public string Password { get => password; set => password = value; }
        public string Fname { get => fname; set => fname = value; }
        public string Job_type { get => job_type; set => job_type = value; }
        public string Qualification { get => qualification; set => qualification = value; }

        //  public int Login_no { get => login_no; set => login_no = value; }

        public void userregistration()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(user_id) from userregister ", con);
            int userid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                userid = (int)cMax;
                userid++;
            }
            else
            {
                userid = 101;
            }
            string qry = "insert into userregister values('" + userid+"',@fname,@lname,@dob,@email_id,@gender,@contact_no,@address,@nationality,@occupation,@password )";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@fname", fname);
            cmd.Parameters.AddWithValue("@lname", lname);
            cmd.Parameters.AddWithValue("@dob", dob);
            cmd.Parameters.AddWithValue("@email_id", email_id);
            cmd.Parameters.AddWithValue("@gender", gender);
            cmd.Parameters.AddWithValue("@contact_no", contact_no);
            cmd.Parameters.AddWithValue("@address", address );
            cmd.Parameters.AddWithValue("@nationality", nationality);
            cmd.Parameters.AddWithValue("@occupation", occupation );
            cmd.Parameters.AddWithValue("@password", password );
            cmd.ExecuteNonQuery();
        }

        //<.........Staff Registration.............>

        public void staffregistration()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(staffid) from staffregister ", con);
            int sid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                sid = (int)cMax;
                sid++;
            }
            else
            {
                sid = 11;
            }
            string qry = "insert into staffregister values('" + sid + "',@fname,@lname,@email_id,@dob,@contact_no,@gender,@address,@jobtype,@qualification,@password)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@fname", Fname);
            cmd.Parameters.AddWithValue("@lname", Lname);
            cmd.Parameters.AddWithValue("@email_id", Email_id);
            cmd.Parameters.AddWithValue("@dob", Dob);
            cmd.Parameters.AddWithValue("@contact_no", Contact_no);
            cmd.Parameters.AddWithValue("@gender", Gender);
            cmd.Parameters.AddWithValue("@address", Address);
            cmd.Parameters.AddWithValue("@jobtype", Job_type);
            cmd.Parameters.AddWithValue("@qualification", Qualification);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.ExecuteNonQuery();

        }


    }
}