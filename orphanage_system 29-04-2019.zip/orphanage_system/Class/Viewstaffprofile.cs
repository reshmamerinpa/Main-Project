﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace orphanage_system.Class
{
    public class Viewstaffprofile
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function

            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        private string fname;
        private string lname;
        private string dob;
        private string email_id;
        private string contact_no;
        private string address;
        private String jobtype;
        private string qualification;




        public string Fname { get => fname; set => fname = value; }
        public string Lname { get => lname; set => lname = value; }
        public string Dob { get => dob; set => dob = value; }
        public string Email_id { get => email_id; set => email_id = value; }
        public string Contact_no { get => contact_no; set => contact_no = value; }
        public string Address { get => address; set => address = value; }
       
        public string Qualification { get => qualification; set => qualification = value; }
        public string Jobtype { get => jobtype; set => jobtype = value; }

        public DataTable ExecuteSelectQueries()
        {
            OpenConection();

            String qry = "select * from staffregister ";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.ExecuteNonQuery();

            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dtReg1 = new DataTable();
            da.Fill(dtReg);

            return dtReg;

        }
        public DataTable disply()
        {
            DataTable dtReg = new DataTable();
            OpenConection();

            String qry = "select * from staffregister where email_id=@email_id";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@email_id", Email_id );
            cmd.ExecuteNonQuery();
            CloseConnection();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);

            CloseConnection();
            return dtReg;

        }

        public void update()
        {

            OpenConection();


            String qry1 = "update staffregister set fname=@fname,lname=@lname,dob=@dob,jobtype=@jobtype,contact_no=@contact_no,address=@address,qualification=@qualification where email_id=@email_id ";

            SqlCommand cmd1 = new SqlCommand(qry1, con);

            cmd1.Parameters.AddWithValue("@email_id", Email_id);
            cmd1.Parameters.AddWithValue("@fname", Fname);
            cmd1.Parameters.AddWithValue("@lname", Lname);
            cmd1.Parameters.AddWithValue("@dob", Dob);
            cmd1.Parameters.AddWithValue("@contact_no", Contact_no);
            cmd1.Parameters.AddWithValue("@address", Address);
            cmd1.Parameters.AddWithValue("@jobtype", Jobtype);
            cmd1.Parameters.AddWithValue("@qualification", Qualification);
            cmd1.ExecuteNonQuery();
         }
        }
}