﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace orphanage_system.Class
{
    public class Sponsor
    {

        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function

            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        private string child_age;
        private string gender;
        private string no_of_child;
        private string no_of_year;
        private string mssg;
        private int user_id;

        public string Child_age { get => child_age; set => child_age = value; }
        public string Gender { get => gender; set => gender = value; }
        public string No_of_child { get => no_of_child; set => no_of_child = value; }
        public string No_of_year { get => no_of_year; set => no_of_year = value; }
        public string Mssg { get => mssg; set => mssg = value; }
       // public int Userid { get => userid; set => userid = value; }
        public int User_id { get => user_id; set => user_id = value; }

        public void sponsor_a_child()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(sid) from tbl_sponsorreq ", con);
            int s_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                s_id = (int)cMax;
                s_id++;
            }
            else
            {
                s_id = 1;
            }

            string qry = "insert into tbl_sponsorreq values('"+s_id + "',@user_id,@child_age,@gender,@no_of_child,@no_of_year,@mssg)";
           
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@userid", User_id);
            cmd.Parameters.AddWithValue("@child_age", Child_age  );
            cmd.Parameters.AddWithValue("@gender", Gender );
            cmd.Parameters.AddWithValue("@no_of_child", No_of_child);
            cmd.Parameters.AddWithValue("@no_of_year", No_of_year );
            cmd.Parameters.AddWithValue("@mssg",Mssg  );
           
            cmd.ExecuteNonQuery();
        }
    }
}