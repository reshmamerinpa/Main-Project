﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace orphanage_system.Class
{
    public class Event
    {

        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function

            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        private string ev_name;
       
        private string ev_description;
        private string ev_date;
        private string ev_time;
        private string ev_venue;
        private string ev_image;

        public string Ev_name { get => ev_name; set => ev_name = value; }
        public string Ev_description { get => ev_description; set => ev_description = value; }
        public string Ev_date { get => ev_date; set => ev_date = value; }
        public string Ev_time { get => ev_time; set => ev_time = value; }
        public string Ev_venue { get => ev_venue; set => ev_venue = value; }
        public string Ev_image { get => ev_image; set => ev_image = value; }
       

        public void addevent()
        {

            OpenConection();
            SqlCommand command = new SqlCommand("Select max(event_id) from tbl_event ", con);
            int eventid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                eventid = (int)cMax;
                eventid++;
            }
            else
            {
                eventid = 1;
            }
           
            string qry = "insert into tbl_event values('"+ eventid+"',@ev_name,@ev_description,@ev_date,@ev_time,@ev_venue,@ev_image)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@ev_name", Ev_name );
            
            cmd.Parameters.AddWithValue("@ev_description",Ev_description);
            cmd.Parameters.AddWithValue("@ev_date", Ev_date);
            cmd.Parameters.AddWithValue("@ev_time", Ev_time);
            cmd.Parameters.AddWithValue("@ev_venue", Ev_venue);
            cmd.Parameters.AddWithValue("@ev_image", Ev_image );
            cmd.ExecuteNonQuery();
        }
    }
}