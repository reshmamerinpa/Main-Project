﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using orphanage_system.Class;
using System.Data;
using System.Data.SqlClient;


namespace orphanage_system.staff
{
    public partial class viewmyprofile : System.Web.UI.Page
    {
        Viewstaffprofile sview = new Viewstaffprofile(); 
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["staff"] == null)
            {
                Response.Redirect("~/staff/staffhome.aspx");
            }
            if (!IsPostBack)
            {
                string Uid = Session["staff"].ToString();

                Loaddata();
            }
        }
        public void Loaddata()
        {
            DataTable dtReg = new DataTable();
            sview.Email_id = Session["staff"].ToString();
            dtReg = sview.disply();
            if (dtReg.Rows.Count > 0)
            {

                if (dtReg.Rows[0]["Gender"].ToString() == "male")
                {
                    rdbmale.Checked = true;

                }
                else
                {
                    rdbfemale.Checked = true;
                }
                txtfname.Text = Convert.ToString(dtReg.Rows[0]["fname"]);
                txtlname.Text = Convert.ToString(dtReg.Rows[0]["lname"]);
               txtdob.Text = Convert.ToString(dtReg.Rows[0]["dob"]);
                txtemail_id.Text = Convert.ToString(dtReg.Rows[0]["email_id"]);
                txtno.Text = Convert.ToString(dtReg.Rows[0]["contact_no"]);
                txtaddress.Text = Convert.ToString(dtReg.Rows[0]["address"]);
                dpdjob.Text = Convert.ToString(dtReg.Rows[0]["jobtype"]);
                txtqualification.Text = Convert.ToString(dtReg.Rows[0]["qualification"]);

            }
        }
       
        

        protected void btnupdate_Click1(object sender, EventArgs e)
        {
            sview.Email_id = Session["staff"].ToString();
            sview.Fname = txtfname.Text;
            sview.Lname = txtlname.Text;
            sview.Dob = txtdob.Text;

            sview.Contact_no = txtno.Text;
            sview.Address = txtaddress.Text;
            sview.Jobtype = dpdjob.Text;
            sview.Qualification = txtqualification.Text;

            sview.update();
        }

        protected void btnedit_Click(object sender, EventArgs e)
        {
            txtfname.Enabled = true;
            txtlname.Enabled = true;
            txtdob.Enabled = true;
            txtno.Enabled = true;
            txtaddress.Enabled = true;
            dpdjob.Enabled = true;
                    
            txtqualification.Enabled = true;
            //txtemail_id.Enabled = true;
            btnupdate.Visible = true;
            btnedit.Visible = false;
        }
    }
}