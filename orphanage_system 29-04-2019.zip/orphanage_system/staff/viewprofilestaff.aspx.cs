﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;
//using System.Web.UI;
//using System.Web.UI.WebControls;
//using orphanage_system.Class;
//using System.Data;
//using System.Data.SqlClient;

//namespace orphanage_system.staff
//{
//    public partial class viewprofilestaff : System.Web.UI.Page
//    {
//        Viewmyprofile stobj = new Viewmyprofile();
//        protected void Page_Load(object sender, EventArgs e)
//        {
//            if (HttpContext.Current.Session["staff"] == null)
//            {
//                Response.Redirect("~/staff/staffhome.aspx");
//            }
//            else if (!IsPostBack)
//            {
//                DataTable dt = new DataTable();
//                stobj.Email_id = Convert.ToString(Session["staff"]);
//                dt = stobj.showdata1();
//                if (dt.Rows.Count > 0)
//                {
//                    DetailsView1.DataSource = dt;
//                    DetailsView1.DataBind();
//                }
//            }

//        }
//    }
//}