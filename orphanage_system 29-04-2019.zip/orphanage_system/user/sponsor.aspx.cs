﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using orphanage_system.Class;
using System.Data;
using System.Data.SqlClient;

namespace orphanage_system.user
{
    public partial class sponsor : System.Web.UI.Page
    {

        Sponsor sp = new Sponsor();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btncnfrm_Click(object sender, EventArgs e)
        {

            if (rdbgirl.Checked)
            {
                sp.Gender = rdbgirl.Text;
            }
            else
            {
                sp.Gender = rdbboy.Text;
            }
           // sp.User_id = Convert.ToInt32(Session["user_id"]);
            
            sp.Child_age = dpdage.Text;
            sp.No_of_child = txtno_of_child.Text;
            sp.No_of_year = txtno_of_year.Text;
            sp.Mssg = txtmsg.Text;
           
            sp.sponsor_a_child();
            

        }
    }
}