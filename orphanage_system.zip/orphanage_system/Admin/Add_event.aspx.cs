﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using orphanage_system.Class;
using System.Data;
using System.IO;
using System.Data.SqlClient;

namespace orphanage_system.Admin
{
    public partial class Add_event : System.Web.UI.Page
    {
        Event eve = new Event();

        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void btnadd_Click(object sender, EventArgs e)
        {

            eve.Ev_name = txteventname.Text;
            eve.Ev_description = txtdescription.Text;

            eve.Ev_date = txtdate.Text;
            eve.Ev_time = txttime.Text;
            eve.Ev_venue = txtvenue.Text;

            string filename = Path.GetFileName(fileup.PostedFile.FileName);
            string ext = Path.GetExtension(filename);
            if (ext.ToLower() == ".jpg" || ext.ToLower() == ".bmp" || ext.ToLower() == ".png" || ext.ToLower() == ".jpeg")
            {
                string src = Server.MapPath("~/Photo") + "\\" + txteventname.Text + ".JPG";
                fileup.PostedFile.SaveAs(src);
                string picpath = "~/Photo/" + txteventname.Text + ".JPG";
                eve.Ev_image = picpath;
            }


            eve.addevent();
        }
    }
}
