﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using orphanage_system.Class;
using System.Data;
using System.Data.SqlClient;

namespace orphanage_system.Admin
{
    public partial class Add_child : System.Web.UI.Page
    {
        Child child = new Child();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            if (rdbfemale.Checked)
            {
                child.Gender = rdbfemale.Text;
            }
            else
            {
                child.Gender = rdbmale.Text;
            }

            child.Cname = txtchildname.Text;
            child.Dob = txtdob.Text;
            child.Age = int.Parse (txtage.Text);
            child.Story = txtstory.Text;
            child.Place = txtplace.Text;
            child.District = txtdistrict.Text;
            child.State = txtstate.Text;
            child.Std = int.Parse (txtclass.Text);
            child.Sname = txtschoolname.Text;
            child.Saddress = txtsaddress.Text;
            child.Interest = txtinterest.Text;
            child.Fathername = txtfathername.Text;
            child.Mothername = txtmothername.Text;
            child.Haddress = txthaddress.Text;

            child.addchild();
        }


    }
}