﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using orphanage_system.Class;
using System.Data;
using System.Data.SqlClient;
namespace orphanage_system.Admin
{
    public partial class viewusers : System.Web.UI.Page
    {
        view_user_staff vuobj = new view_user_staff();
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void LoadData()
        {
            DataTable dtReg = new DataTable();
            view_user_staff Obj = new view_user_staff();
            dtReg = Obj.ExecuteSelectQueries();
            if (dtReg.Rows.Count > 0)
            {
                GridView1.DataSource = dtReg;
                GridView1.DataBind();
            }
        }

       
    }
}