﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using orphanage_system.Class;
using System.Data;
using System.IO;
using System.Data.SqlClient;

namespace orphanage_system.Admin
{
    public partial class contact_us : System.Web.UI.Page
    {
        // Contact cn = new Contact();
        orphanage_system.Class.Contact cn = new Class.Contact();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsbmt_Click(object sender, EventArgs e)
        {
            cn.Fname = txtfname.Text;
            cn.Lname = txtlname.Text;
            cn.Email = txtemail.Text;
            cn.Contact_no = txtcontact_no.Text;
            cn.Address = txtaddress.Text;
            cn.Country = txtcountry.Text;
            cn.Msg = txtmsg.Text;

            cn.contact();

        }


    }
}