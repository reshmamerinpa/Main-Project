﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace orphanage_system.Class
{
    public class Contact
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function

            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        private string fname;
        private string lname;
        private string email;
        private string contact_no;
        private string address;
        private string country;
        private string msg;

        public string Fname { get => fname; set => fname = value; }
        public string Lname { get => lname; set => lname = value; }
        public string Email { get => email; set => email = value; }
        public string Contact_no { get => contact_no; set => contact_no = value; }
        public string Address { get => address; set => address = value; }
        public string Country { get => country; set => country = value; }
        public string Msg { get => msg; set => msg = value; }

        public void contact()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(cid) from tbl_contact ", con);
            int c_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                c_id = (int)cMax;
                c_id++;
            }
            else
            {
                c_id = 1;
            }
            string qry = "insert into tbl_contact values('" + c_id + "',@fname,@lname,@email,@contact_no,@address,@country,@msg)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@fname", fname );
            cmd.Parameters.AddWithValue("@lname", lname );
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@contact_no", contact_no );
            cmd.Parameters.AddWithValue("@address", address );
            cmd.Parameters.AddWithValue("@country", country );
            cmd.Parameters.AddWithValue("@msg", msg);
            cmd.ExecuteNonQuery();

        }
    }
}