﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace orphanage_system.Class
{
    public class userlogin
    {

        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function

            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        private string email_id;
        private string password;
       // private string utype;

        public string Email_id { get => email_id; set => email_id = value; }
        public string Password { get => password; set => password = value; }
       // public string Utype { get => utype; set => utype = value; }

        public DataTable ExecuteSelectQueries()

        {

            OpenConection();
            string qry = "select * from  userregister  where email_id=@email_id and password= @password ";
            
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@email_id", email_id);
            cmd.Parameters.AddWithValue("@password", password);

            cmd.ExecuteNonQuery();

            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;
        }
        public DataTable stafflogin()
        {
            OpenConection();
            string qry1 = "select * from  staffregister  where email_id=@email_id and password= @password ";

            SqlCommand cmd1 = new SqlCommand(qry1, con);
            cmd1.Parameters.AddWithValue("@email_id", email_id);
            cmd1.Parameters.AddWithValue("@password", password);

            cmd1.ExecuteNonQuery();

            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;
        }

    }
}