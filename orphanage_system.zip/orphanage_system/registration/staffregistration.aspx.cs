﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using orphanage_system.Class;
using System.Data;
using System.Data.SqlClient;

namespace orphanage_system.registration
{
    public partial class staffregistration : System.Web.UI.Page
    {
        Registration sreg = new Registration();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            if (rdbfemale.Checked)
            {
                sreg.Gender = rdbfemale.Text;
            }
            else
            {
                sreg.Gender = rdbmale.Text;
            }
            sreg.Fname = txtfname.Text;
            sreg.Lname = txtlname.Text;
            sreg.Email_id = txtemail.Text;
            sreg.Dob = txtdob.Text;
            sreg.Contact_no = txtcontact_no.Text;
            sreg.Address = txtaddress.Text;
            sreg.Job_type  = dpdjobtype.Text;
            sreg.Qualification  = txtqualification.Text;
            sreg.Password = txtpass.Text;
          //  sreg.insertlogin();
            sreg.staffregistration();
          
            Response.Redirect("login.aspx");
        }

       
    }
}