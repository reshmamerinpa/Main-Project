﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using orphanage_system.Class;
using System.Data;
using System.Data.SqlClient;

namespace orphanage_system.registration
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {

            DataTable dtUReg = new DataTable();
            DataTable dtSReg = new DataTable();

            userlogin log = new userlogin();
            log.Email_id = txtemail_id.Text;
            log.Password = txtpassword.Text;
            dtUReg = log.ExecuteSelectQueries();
            dtSReg = log.stafflogin ();
            if (log.Email_id == "admin@gmail.com" && log.Password == "admin")
            {
                Session["admin"] = txtemail_id.Text;
                Response.Redirect("~/Admin/adminhome.aspx");
            }
            else if(dtUReg .Rows.Count>0)
            {
                Session["user"] = txtemail_id.Text;
                Session["user_id"] = Convert.ToString(dtUReg.Rows[0]["user_id"]);
                Response.Redirect("~/user/userhome.aspx");
            }
            else if(dtSReg .Rows .Count > 0)
            {
                Session["staff"] = txtemail_id.Text;
                Session["staffid"] = Convert.ToString(dtSReg.Rows[0]["staffid"]);
                Response.Redirect("~/staff/staffhome.aspx");
            }
            else
            {
                Response.Write("<script>alert('invalid username or password')</script>");
            }

           

        }
    }
    }
