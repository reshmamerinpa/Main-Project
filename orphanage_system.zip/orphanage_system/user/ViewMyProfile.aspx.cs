﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using orphanage_system.Class;
using System.Data;
using System.Data.SqlClient;

namespace orphanage_system.user
{
    public partial class ViewMyProfile : System.Web.UI.Page
    {
        
       Viewstaffprofile sview = new Viewstaffprofile();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["user"] == null)
            {
                Response.Redirect("~/user/userhome.aspx");
            }
            if (!IsPostBack)
            {
                string Uid = Session["user"].ToString();

                Loaddata();
            }
        }
        public void Loaddata()
        {
            DataTable dtReg = new DataTable();
            sview.Email_id = Session["user"].ToString();
            dtReg = sview.disply1();
            if (dtReg.Rows.Count > 0)
            {

                if (dtReg.Rows[0]["Gender"].ToString() == "male")
                {
                    rdbmale.Checked = true;

                }
                else
                {
                    rdbfemale.Checked = true;
                }
                txtfname.Text = Convert.ToString(dtReg.Rows[0]["fname"]);
                txtlname.Text = Convert.ToString(dtReg.Rows[0]["lname"]);
                txtdob.Text = Convert.ToString(dtReg.Rows[0]["dob"]);
                txtemail_id.Text = Convert.ToString(dtReg.Rows[0]["email_id"]);
                txtno.Text = Convert.ToString(dtReg.Rows[0]["contact_no"]);
                txtaddress.Text = Convert.ToString(dtReg.Rows[0]["address"]);
                txtnationality.Text = Convert.ToString(dtReg.Rows[0]["nationality"]);
                txtoccupation.Text = Convert.ToString(dtReg.Rows[0]["occupation"]);


            }
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            sview.Email_id = Session["user"].ToString();
            sview.Fname = txtfname.Text;
            sview.Lname = txtlname.Text;
            sview.Dob = txtdob.Text;
            sview.Contact_no = txtno.Text;
            sview.Address = txtaddress.Text;
            sview.Nationality = txtnationality.Text;
            sview.Occupation  = txtoccupation.Text;

            sview.update1();
        }

        protected void btnedit_Click(object sender, EventArgs e)
        {
            txtfname.Enabled = true;
            txtlname.Enabled = true;
            txtdob.Enabled = true;
            txtemail_id.Enabled = true;
            txtno.Enabled = true;

            txtaddress.Enabled = true;
            txtnationality.Enabled = true;
            txtoccupation.Enabled = true;

            //txtemail_id.Enabled = true;
            btnupdate.Visible = true;
            btnedit.Visible = false;
        }
    }
}