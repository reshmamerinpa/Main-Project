﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using orphanage_system.Class;
using System.Data;
using System.Data.SqlClient;

namespace orphanage_system.registration
{
    public partial class UserRegistration : System.Web.UI.Page
    {
        Registration reg = new Registration();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
          if (rdbfemale.Checked)
            {
                reg.Gender = rdbfemale.Text;
            }
          else
            {
                reg.Gender = rdbmale.Text;
            }
            reg.Fname = txtfname.Text;
            reg.Lname = txtlname.Text;
            reg.Dob = txtdob.Text;
            reg.Email_id = txtemail.Text;
            reg.Contact_no = txtno.Text;
            reg.Address = txtaddress.Text;
            reg.Nationality = txtnationality.Text;
            reg.Occupation = txtoccupation.Text;
            reg.Password = txtpass.Text;

            reg.registration();
            reg.insertlogin();


            
        
                        
            Response.Redirect("login.aspx");

        }
    }
}