﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using orphanage_system.Class;
using System.Data;
using System.Data.SqlClient;

namespace orphanage_system.registration
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {

            DataTable dtReg = new DataTable();
            userlogin log = new userlogin ();
            log.Email_id = txtemail_id.Text;
           log.Password = txtpassword.Text;
            dtReg = log.ExecuteSelectQueries();
            if (dtReg.Rows.Count > 0)
            {
                lblmsg.Text = " Sucess.";

            }
            else
            {
                lblmsg.Text = " Incorrect Try again..!!";
            }
        }
    }
}