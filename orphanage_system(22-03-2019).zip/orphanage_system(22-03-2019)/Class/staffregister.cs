﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace orphanage_system.Class
{
    public class staffregister
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }


        private string fname;
        private string lname;
        private string email_id;
        private string dob;
        private string contact_no;
        private string gender;
        private string address;
        private string job_type;
        private string qualification;
        private string password;

        public string Fname { get => fname; set => fname = value; }
        public string Lname { get => lname; set => lname = value; }
        public string Email_id { get => email_id; set => email_id = value; }
        public string Dob { get => dob; set => dob = value; }
        public string Contact_no { get => contact_no; set => contact_no = value; }
        public string Gender { get => gender; set => gender = value; }
        public string Address { get => address; set => address = value; }
        public string Job_type { get => job_type; set => job_type = value; }
        public string Qualification { get => qualification; set => qualification = value; }
        public string Password { get => password; set => password = value; }

        public void stregistration()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(staffid) from StaffRegistration ", con);
            int sid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                sid = (int)cMax;
                sid++;
            }
            else
            {
               sid = 1;
            }
            string qry = "insert into StaffRegistration values('" + sid + "',@fname,@lname,@dob,@email_id,@gender,@contact_no,@address,@jobtype,@qualification,@password)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@fname", Fname);
            cmd.Parameters.AddWithValue("@lname", Lname);
            cmd.Parameters.AddWithValue("@dob", Dob);
            cmd.Parameters.AddWithValue("@email_id", Email_id);
            cmd.Parameters.AddWithValue("@gender", Gender);
            cmd.Parameters.AddWithValue("@contact_no", Contact_no);
            cmd.Parameters.AddWithValue("@address", Address);
            cmd.Parameters.AddWithValue("@jobtype", Job_type );
            cmd.Parameters.AddWithValue("@qualification", Qualification );
            cmd.Parameters.AddWithValue("@password",password);
            cmd.ExecuteNonQuery();

        }

        public void insertlogin()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("select max(login_id) from login ", con);
            int login_no;
            string utype;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                login_no = (int)cMax;
                login_no++;
            }
            else
            {
                login_no = 1;
            }
            utype = "Staff";
            string qry = "insert into login values('" + login_no + "',@email_id,@password,'"+utype+"')";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@email_id", email_id);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.ExecuteNonQuery();

        }


    }
}