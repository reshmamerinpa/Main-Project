﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace orphanage_system.Class
{
    public class Registration
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
           
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        private string fname;
        private string lname;
        private string dob;
        private string email_id;
        private string gender;
        private string contact_no;
        private string address;
        private string nationality;
        private string occupation;
        private string password;
        


        public string Lname { get => lname; set => lname = value; }
        public string Dob { get => dob; set => dob = value; }
        public string Email_id { get => email_id; set => email_id = value; }
        public string Gender { get => gender; set => gender = value; }
        public string Contact_no { get => contact_no; set => contact_no = value; }
        public string Address { get => address; set => address = value; }
        public string Nationality { get => nationality; set => nationality = value; }
        public string Occupation { get => occupation; set => occupation = value; }
        public string Password { get => password; set => password = value; }
        public string Fname { get => fname; set => fname = value; }
        

        public void registration()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(userid) from UserRegistration ", con);
            int userid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                userid = (int)cMax;
                userid++;
            }
            else
            {
                userid = 1;
            }
            string qry = "insert into UserRegistration values('"+userid+"',@fname,@lname,@dob,@email_id,@gender,@contact_no,@address,@nationality,@occupation,@password)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@fname", fname);
            cmd.Parameters.AddWithValue("@lname", lname);
            cmd.Parameters.AddWithValue("@dob", dob);
            cmd.Parameters.AddWithValue("@email_id", email_id);
            cmd.Parameters.AddWithValue("@gender", gender);
            cmd.Parameters.AddWithValue("@contact_no", contact_no);
            cmd.Parameters.AddWithValue("@address", address );
            cmd.Parameters.AddWithValue("@nationality", nationality);
            cmd.Parameters.AddWithValue("@occupation", occupation );
            cmd.Parameters.AddWithValue("@password", password );
            cmd.ExecuteNonQuery();
        }

        public void insertlogin()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("select max(login_id) from login ", con);
            int login_no;
            string utype;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value  )
            {
                login_no = (int)cMax;
                login_no++;
            }
            else
            {
                login_no = 1;
            }
            utype = "user";
            string qry="insert into login values('"+ login_no +"',@email_id,@password,'"+utype+"')";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@email_id", email_id);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.ExecuteNonQuery();
        }


        
    }
}