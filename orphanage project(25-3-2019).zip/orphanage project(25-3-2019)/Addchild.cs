﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace orphanage_system.Class
{
    public class Addchild
    {


        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function

            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        private string cname;
        private string gender;
        private string dob;
        private string story;
        private string place;
        private string district;
        private string state;
        private string std;
        private string sname;
        private string saddress;
        private string interest;
        private string dadname;
        private string momname;
        private string haddress;




        public string Cname { get => cname; set => cname = value; }
        public string Gender { get => gender; set => gender = value; }
        public string Dob { get => dob; set => dob = value; }
        public string Story { get => story; set => story = value; }
        public string Place { get => place; set => place = value; }
        public string District { get => district; set => district = value; }
        public string State { get => state; set => state = value; }
        public string Std { get => std; set => std = value; }
        public string Sname { get => sname; set => sname = value; }
        public string Saddress { get => saddress; set => saddress = value; }
        public string Interest { get => interest; set => interest = value; }
        public string Dadname { get => dadname; set => dadname = value; }
        public string Momname { get => momname; set => momname = value; }
        public string Haddress { get => haddress; set => haddress = value; }



        public void addchild()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(child_id) from tbl_child ", con);
            int childid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                childid = (int)cMax;
                childid++;
            }
            else
            {
                childid = 1;
            }

            string qry = "insert into tbl_child values('" + childid + "',@c_name,@c_gender,@c_dob,@c_story,@c_place,@c_district,@c_state,@c_class,@c_sname,@c_saddress,@c_interest,@c_fname,@c_mname,@c_haddress)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@c_name", cname );
            cmd.Parameters.AddWithValue("@c_gender", gender );
            cmd.Parameters.AddWithValue("@c_dob", dob);
            cmd.Parameters.AddWithValue("@c_story", story);
            cmd.Parameters.AddWithValue("@c_place", place );
            cmd.Parameters.AddWithValue("@c_district", district );
            cmd.Parameters.AddWithValue("@c_state", state);
            cmd.Parameters.AddWithValue("@c_class", std);
            cmd.Parameters.AddWithValue("@c_sname", sname);
            cmd.Parameters.AddWithValue("@c_saddress", saddress );
            cmd.Parameters.AddWithValue("@c_interest", interest);
            cmd.Parameters.AddWithValue("@c_fname", dadname);
            cmd.Parameters.AddWithValue("@c_mname", momname );
            cmd.Parameters.AddWithValue("@c_haddress", haddress);
             cmd.ExecuteNonQuery();
        }
    }
}